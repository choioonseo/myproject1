package com.multicampus.boot2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot21Application {

	public static void main(String[] args) {
		SpringApplication.run(Boot21Application.class, args);
	}

}
