package com.multicampus.boot2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
